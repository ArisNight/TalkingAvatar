-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)
